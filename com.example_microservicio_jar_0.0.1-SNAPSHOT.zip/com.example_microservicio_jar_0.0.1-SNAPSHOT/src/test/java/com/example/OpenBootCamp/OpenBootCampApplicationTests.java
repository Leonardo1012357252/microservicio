package com.example.OpenBootCamp;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenBootCampApplicationTests {

}
