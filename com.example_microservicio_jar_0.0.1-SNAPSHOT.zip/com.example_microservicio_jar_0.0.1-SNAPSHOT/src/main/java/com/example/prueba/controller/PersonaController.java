package com.example.prueba.controller;

import com.example.prueba.entity.persona;
import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.prueba.Repository.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * @author leona
 */
@RestController
public class PersonaController {

    @Autowired
    PersonaRepository personasRepositorio;

    public PersonaController(PersonaRepository libros) {
        this.personasRepositorio = libros;
    }
    //Buscar todos.

    @GetMapping("/Buscar")
    public ResponseEntity<List> mostarpersonas() {
        return new ResponseEntity<>((List<persona>) personasRepositorio.findAll(), HttpStatus.OK);
    }

    //Buscar filtro por cedula y tipo.
    @GetMapping("/Buscardos/{cedula}/{tipo_doc}")
    public ResponseEntity<persona> Buscaruno2(@PathVariable("cedula") String cedula, @PathVariable("tipo_doc") String tipo_doc) throws Exception {
        if (tipo_doc.equals("C") || (tipo_doc.equals("P"))) {
            persona BDpersona = personasRepositorio.findAllBycedulaAndtipo_doc(cedula, tipo_doc);
            return new ResponseEntity<>(BDpersona, HttpStatus.OK);
        }
        throw new Exception("Error : " + tipo_doc + " No valido como parametro inicial");
    }

    //Guardar
    @PostMapping("/Guardar")
    @ResponseStatus(HttpStatus.CREATED)
    public persona save(@RequestBody persona Persona) {
        return personasRepositorio.save(Persona);
    }
    //Borrar.

    @DeleteMapping("/Borrar/{id}")
    public ResponseEntity<persona> delete(@PathVariable("id") Long id) {
        personasRepositorio.deleteById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
