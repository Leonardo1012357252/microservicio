package com.example.prueba;

import com.example.prueba.entity.persona;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.example.prueba.Repository.PersonaRepository;

@SpringBootApplication
public class OpenBootCampApplication {
 
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(OpenBootCampApplication.class, args);
        PersonaRepository repository = context.getBean(PersonaRepository.class);
     //
     
     persona persona1 = new persona(null,"12345","C" ,"Juan", "Dario", "Diaz", "Gomez", 54321, "Calle falsa 123", "Bogota");
     persona persona2 = new persona(null,"23445322","C" ,"Juan", "Dario", "Diaz", "Gomez", 54321, "Calle falsa 123", "Bogota");

     repository.save(persona1);
     //
     
        System.out.println(repository.findAll());
       
     
     
    }

}
