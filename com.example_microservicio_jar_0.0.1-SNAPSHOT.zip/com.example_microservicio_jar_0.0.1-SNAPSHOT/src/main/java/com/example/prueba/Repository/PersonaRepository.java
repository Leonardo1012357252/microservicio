/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.prueba.Repository;

import com.example.prueba.entity.persona;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.ui.Model;

/**
 *
 * @author leona
 */
public interface PersonaRepository extends CrudRepository<persona, Long> {

    @Query("Select c from persona c where c.cedula = ?1 and tipo_doc = ?2")
    public persona findAllBycedulaAndtipo_doc(String cedula,String tipo_doc);
    
   
    }
